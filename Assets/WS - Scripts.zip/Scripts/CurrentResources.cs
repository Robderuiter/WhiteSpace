﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CurrentResources : MonoBehaviour {

	//resource classes
	//public float[] planetModifiers;
	public float[] resourceMultipliers;
	public GameObject parentGameObject;
	public Planet planet;
	public Population pop;
	public Food food;
	public Water water;

	//timer
	public bool isActive = false;
	float timer;
	float tickLength = 5;

	//module array
	public Module[] mod;
	public List<Module> modList = new List<Module>();

	//resource array
	public Resource[] res;

	// Use this for initialization
	void Start () {
		planet = GetComponentInParent<Planet>();
		//print (this + " planet = " + planet);
		//print ("planetModifiers on currentresources = " + planetModifiers[0] + ", also nresMultipliers = " + planet.nResourceMultipliers + ", planet.resourcemult[0] = " + planet.resourceMultipliers[0]);

		pop = new Population (this);
		food = new Food (this);
		water = new Water (this);
		res = new Resource[3]{pop, food, water};

		//set timer
		timer = tickLength;
	}

	void Update(){
		if (isActive == true) {
			timer -= Time.deltaTime;
			if (timer < 0) {
				Debug.Log ("resourceMultipliers = " + resourceMultipliers[0]);

				//for each resource, calc changes
				for (int q = 0; q < res.Length; q++) {
					res[q].Calc (resourceMultipliers[q]);
				}

				//for each mod, adjust change in resource subclasses
				foreach (Module mod in modList){
					mod.DoYourThang ();
					//Debug.Log (mod);
				}

				//for each resource, apply change
				for (int q = 0; q < res.Length; q++) {
					res [q].ApplyChange ();
				}

				//reset timer
				timer = tickLength;
			}
		}
	}

	//called on planet type subclasses (Earthlike, Desert..)
	public void InitResources(float[] resourceTresholds){
		pop.amount = Random.Range(resourceTresholds[0],resourceTresholds[1]);
		food.amount = Random.Range(resourceTresholds[2],resourceTresholds[3]);
		water.amount = Random.Range(resourceTresholds[4],resourceTresholds[5]);
		water.max = water.amount;
		//so that water is already set to account for current population
		water.Calc (resourceMultipliers[2]);
		/*
		iron = Random.Range(resourceTresholds[6],resourceTresholds[7]);
		oxygen = Random.Range(resourceTresholds[8],resourceTresholds[9]);
		power = Random.Range(resourceTresholds[10],resourceTresholds[11]);
		stone = Random.Range(resourceTresholds[12],resourceTresholds[13]);
		research = Random.Range(resourceTresholds[14],resourceTresholds[15]);
		pollution = Random.Range(resourceTresholds[16],resourceTresholds[17]);
		flora = Random.Range(resourceTresholds[18],resourceTresholds[19]);
		fauna = Random.Range(resourceTresholds[20],resourceTresholds[21]);
		temperature = Random.Range(resourceTresholds[22],resourceTresholds[23]);
		gold = Random.Range(resourceTresholds[24],resourceTresholds[25]);
		*/
	}

	//called on planet and ships
	public void InitStorage(float[] st){
		pop.storage = st[0];
		food.storage = st[1];
		water.storage = st[2];
	}


}
