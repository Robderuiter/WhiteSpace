﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SelectionController : MonoBehaviour {


	//need to redo selection from scratch: currently every gameobject has a selectioncontroller script
	//so when you click on 1 thing, and then another, neither seperate scripts have each others variables..

	//either that or make seperate selection scripts for each major class (Planet, Module, Ship), which is
	//actually kind of fine and allows for all the customization i could want, except for maybe group selection..

	//might want to just create a SelectionMaster class, 
	//specifically designed for holding the current selection as well as later group selection


	static private Transform trSelect = null;
	public bool selected = false;

	public GameObject selectedPlanet;
	public bool modIsSelected = false;
	public bool test;
	public SelectionMaster selectionMaster;

	void Start () {
		selectionMaster = GameObject.Find ("SelectionMaster").GetComponent<SelectionMaster> ();
	}

	// Update is called once per frame
	void Update () {
		if (selected && transform != trSelect) {
			selected = false;
		}
		if (selected && selectedPlanet) {
			//selectionMaster.UpdatePlanetResourceGUI (selectedPlanet);
			selectionMaster.UpdateFloatingInfo ();
		}
	}

	public void OnMouseDown(){
		selected = true;
		trSelect = transform;
		if (gameObject.tag == "Planet" && !selectionMaster.modIsSelected) {
			//local selectedPlanet is currently needed for updating gui
			selectedPlanet = gameObject;
			//also update selectionMaster because reasons
			selectionMaster.selectedObject = gameObject;
			//print (selectionMaster.selectedPlanet);

			selectionMaster.ShowFloatingInfo (Input.mousePosition);
		}
		if (gameObject.tag == "Ship") {
			selectionMaster.selectedObject = gameObject;
			//print (selectionMaster.selectedShip);
		}
		if (gameObject.tag == "Module") {
			selectionMaster.selectedObject = gameObject;
			selectionMaster.module = GetComponent<Module> ();
			selectionMaster.modIsSelected = true;
			print ("selectionMaster.modIsSelected = " + selectionMaster.modIsSelected + ", selectionMaster.module = " + selectionMaster.module + " of gameObject " + gameObject + ", selectionMaster.selectedModule = " + selectionMaster.selectedObject);
		}
		if (gameObject.tag == "Planet" && selectionMaster.modIsSelected) {
			selectionMaster.selectedObject = gameObject;
			selectionMaster.module.AttachModule(selectionMaster.selectedObject);
			selectionMaster.modIsSelected = false;
			print ("selectionMaster.modIsSelected = " + selectionMaster.modIsSelected + ", selectionMaster.selectedPlanet = " + selectionMaster.selectedObject + ", selectionMaster.module = " + selectionMaster.module + ", selectionMaster.selectedModule = " + selectionMaster.selectedObject);
		}
		if (gameObject.tag == "Ship" && selectionMaster.modIsSelected) {
			selectionMaster.selectedObject = gameObject;
			selectionMaster.module.AttachModule(selectionMaster.selectedObject);
			selectionMaster.modIsSelected = false;
			print ("selectionMaster.modIsSelected = " + selectionMaster.modIsSelected + ", selectionMaster.selectedPlanet = " + selectionMaster.selectedObject + ", selectionMaster.module = " + selectionMaster.module + ", selectionMaster.selectedModule = " + selectionMaster.selectedObject);
		}
		if (gameObject.tag == "Background" && !selectionMaster.modIsSelected) {
			selectionMaster.selectedObject = null;
			selectionMaster.selected = false;
			selectionMaster.modIsSelected = false;
			selectionMaster.hideFloatingInfo ();
			print ("Background selected: selected reset");
		}
	}
}
