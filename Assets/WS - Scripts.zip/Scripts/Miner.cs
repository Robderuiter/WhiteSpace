﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Miner : Module {

	Resource extractedRes;

	void Awake(){
		base.Awake();

		nExtracted = 100;
	}

	void Start(){
		base.Start();

		//GetComponent<SelectionController> ().modIsSelected = true;

	
	}

	// Update is called once per frame
	public override void DoYourThang () {
		extractedRes = currentRes.water;
		//needs to be done at currentResources rather than here
		AddToChange (extractedRes, -nExtracted);
	}
}
