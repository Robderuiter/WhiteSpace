﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Water : Resource {

	//setting the reference to the currentResources that called it
	public Water (CurrentResources res){
		myParentsResources = res;
		consumption = 1;
	}

	public override void Calc(float multiplier){
		if (myParentsResources.pop.amount > 0 && amount > 0) {
			Drink (multiplier);
		}
		//Debug.Log ("water amount = " + amount);
	}

	void Drink(float multiplier){
		change = - myParentsResources.pop.change * multiplier;
	}
}
