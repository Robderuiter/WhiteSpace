﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SelectionMaster : MonoBehaviour {

	static private Transform trSelect = null;
	public bool selected = false;

	//public GameObject previouslySelectedObject;
	public GameObject selectedObject;
	public bool modIsSelected = false;
	public Module module;

	//GUI elements
	Text[] planetResourcesGUI;
	Text flavorGUIText;
	CurrentResources currentRes;

	//flavor sprites
	Image[] flavorGUIImage;
	Sprite earthlikeFlavor;
	Sprite desertFlavor;
	Sprite barrenFlavor;
	GameObject flavorGUIPanel;

	//floating info window
	GameObject floatingInfoPanel;
	Text[] infoPanelText;
	Text[] infoPanelChanges;
	Image[] infoPanelImg;
	Camera cam;
	Planet currentPlanet;
	Color dGReen;
	Color red;
	
	//group selection
	Vector2 selectionStartPos;
	Vector2 selectionEndPos;
	bool isSelecting;
	Texture2D selectionBoxTexture;
	GUIStyle guiStyle;
	Rect selectionRect = new Rect(-10000,-10000,0,0);
	GameObject selectionColliderPrefab;
	GameObject selectionBox;
	RectTransform selectionCollider;
	Vector2 selectionStartPosWorld;
	Vector2 selectionEndPosWorld;

	//Time panel
	GameObject timePanel;
	Text[] timeTextHolder;
	int nYears = 0;
	int nTicks = 0;
	int daysInAYear = 365;
	float timer;
	//also defined in currentResources, shouldn be in 2 places but does allow some extra flexibility
	float tickLength = 5;

	//empire overview test
	GameObject shipPrefab;

	void Awake(){
		//colors for text
		dGReen = new Color(0,0.5f,0);
		red = new Color (0.7f,0,0);

		//create selectionBox texture
		selectionBoxTexture = new Texture2D(1,1);
		selectionBoxTexture.SetPixel (0,0,new Color(0,0,0,0.1f));
		selectionBoxTexture.Apply ();

		//create selectionCollider
		selectionColliderPrefab = (GameObject)Resources.Load("SelectionCollider");
		selectionBox = Instantiate(selectionColliderPrefab, new Vector2(10000,10000), transform.rotation);
		//for some auspicious, unknown reason, it doesn't instantiate at the given new vector2, therefore move it after spawning:
		selectionBox.transform.position = new Vector2(-10000,-10000);
		//selectionCollider = selectionBox.GetComponent<BoxCollider2D> ();
		selectionCollider = selectionBox.GetComponent<RectTransform> ();
		selectionBox.SetActive (false);
	}

	// Use this for initialization
	void Start () {
		//floating info window
		floatingInfoPanel = GameObject.Find("FloatingInfoPanel");
		infoPanelText = GameObject.Find("InfoVariables").GetComponentsInChildren<Text>();
		infoPanelChanges = GameObject.Find("ChangeVariables").GetComponentsInChildren<Text>();
		infoPanelImg = GameObject.Find("InfoVariables").GetComponentsInChildren<Image>();
		//maybe instead of SetActive (which might be the cause for some selection bugs) i could just move it outside the camera view
		floatingInfoPanel.gameObject.SetActive(false);

		//time panel
		timePanel = GameObject.Find("TimePanel");
		timeTextHolder = timePanel.GetComponentsInChildren<Text> ();

		//get flavor images
		earthlikeFlavor = Resources.Load<Sprite>("FlavorSprites/planetearth");
		desertFlavor = Resources.Load<Sprite>("FlavorSprites/planetdesert");
		barrenFlavor = Resources.Load<Sprite>("FlavorSprites/planetbarren");

		//Camera
		cam = GameObject.Find("Main Camera").GetComponent<Camera>();

		//testing empire ship overview
		shipPrefab = (GameObject) Resources.Load("Ship");
	}
	
	// Update is called once per frame
	void Update () {
		//timer used for resource
		timer -= Time.deltaTime;
		if (timer < 0) {
			UpdateTimePanel ();
			timer = tickLength;
		}

		//draw group selection box on mousebuttondown
		if (Input.GetMouseButtonDown(0)){
			selectionStartPos = new Vector2(Input.mousePosition.x, Screen.height - Input.mousePosition.y);
			isSelecting = true;
		}
		if (Input.GetMouseButtonUp(0)){
			selectionEndPos = Input.mousePosition;
			isSelecting = false;

			//turn on, center and resize the selection boxcollider, //@@ NOT WORKING PROPERLY!!!!!!
			selectionBox.SetActive(true);
			selectionStartPosWorld = Camera.main.ScreenToWorldPoint(selectionStartPos);
			selectionEndPosWorld = Camera.main.ScreenToWorldPoint(selectionEndPos);
			Vector2 selectionCenter = new Vector2((selectionEndPosWorld.x + selectionStartPosWorld.x)/2,(selectionEndPosWorld.y - selectionStartPosWorld.y)/2);
			float selectionWidth = Mathf.Abs(selectionEndPosWorld.x - selectionStartPosWorld.x);
			//height isnt working correctly yet
			float selectionHeight = Mathf.Abs(selectionEndPosWorld.y + selectionStartPosWorld.y);
			//print ("selectionWidth = " + selectionWidth + ", selectionHeight = " + selectionHeight);

			selectionBox.transform.position = selectionCenter;
			selectionCollider.sizeDelta = new Vector2(selectionWidth, selectionHeight);

			//turn off selectionBox, seems to make sure selection never happens.. which i believe it shouldnt.. :(
			selectionBox.SetActive (false);
		}
		/*
		//testing for empire ship overview, Fire2 = left alt, adding ships
		if (Input.GetButton("Fire2")){
			Instantiate (shipPrefab,Camera.main.ScreenToWorldPoint(Input.mousePosition), transform.rotation);
		}
		*/
	}

	void OnGUI(){
		//set GUI box color
		GUI.skin.box.normal.background = selectionBoxTexture;

		//until mousebuttonup, draw box based on mousepos
		if (isSelecting) {
			selectionEndPos = Input.mousePosition;
			selectionRect.x = Mathf.Min(selectionStartPos.x,selectionEndPos.x) ;
			selectionRect.y = Mathf.Min(selectionStartPos.y, Screen.height - selectionEndPos.y) ;
			selectionRect.width = Mathf.Abs(selectionStartPos.x-selectionEndPos.x) ;
			selectionRect.height = Mathf.Abs(Screen.height - selectionStartPos.y - selectionEndPos.y);

			//instantiate prefab gameobject with collider + image
			GUI.Box (selectionRect,selectionBoxTexture);
		}
	}
  
	public void updateFlavorGUI(){
		if (selectedObject.tag == "Planet") {
			string objectName = selectedObject.GetComponent<Planet> ().typeName;
			if (objectName == "Earthlike" && infoPanelImg[1].sprite != earthlikeFlavor) {
				infoPanelImg [1].sprite = earthlikeFlavor;
			}
			if (objectName == "Desert" && infoPanelImg[1].sprite != desertFlavor) {
				infoPanelImg [1].sprite = desertFlavor;
			}
			if (objectName == "Barren" && infoPanelImg[1].sprite != barrenFlavor) {
				infoPanelImg [1].sprite = barrenFlavor;
			}

		}
	}

	public void ShowFloatingInfo(Vector2 pos){
		floatingInfoPanel.transform.position = pos;
		floatingInfoPanel.SetActive (true);

		UpdateFloatingInfo ();
	}
		
	public void UpdateFloatingInfo(){
		//get current resources
		floatingInfoPanel.transform.position = cam.WorldToScreenPoint(selectedObject.transform.position);

		currentRes = selectedObject.GetComponent<CurrentResources> ();

		updateFlavorGUI ();
		
		if (selectedObject.GetComponent<Planet> ().isScanned) {
			currentPlanet = selectedObject.GetComponent<Planet>();

			//name and type
			infoPanelText [0].text = currentRes.planet.planetName;
			infoPanelText [1].text = currentRes.planet.typeName;

			//resources
			UpdateAmountInfo (currentRes.pop, 2);
			UpdateAmountInfo (currentRes.food, 3);
			UpdateAmountInfo (currentRes.water, 4);

			//building slots
			infoPanelText [15].text = currentPlanet.nModulesAttached + "/" + currentPlanet.nBuildingSlots;

			//update all change amounts
			UpdateChangeInfo(currentRes.pop,0);
			UpdateChangeInfo(currentRes.food,1);
			UpdateChangeInfo(currentRes.water,2);

		} else {
			resetFloatingInfo ();
			for (int j=0;j < infoPanelChanges.Length;j++){
				resetChangeInfo (j);
			}
		}
	}

	void UpdateAmountInfo(Resource res, int n){
		infoPanelText[n].text = res.amount.ToString ("0");
	}

	void resetFloatingInfo (){
		//alvast volledig gedaan want superhandig lijstje om te hebben
		infoPanelText [0].text = selectedObject.GetComponent<Planet>().planetName;
		infoPanelText [1].text = currentRes.planet.typeName.ToString ();
		infoPanelText [2].text = "Pop";
		infoPanelText [3].text = "Food";
		infoPanelText [4].text = "Water";
		infoPanelText [5].text = "Oxygen";
		infoPanelText [6].text = "Power";
		infoPanelText [7].text = "Flora";
		infoPanelText [8].text = "Fauna";
		infoPanelText [9].text = "Stone";
		infoPanelText [10].text = "Iron";
		infoPanelText [11].text = "Pollution";
		infoPanelText [12].text = "Temperature";
		infoPanelText [13].text = "Gold";
		infoPanelText [14].text = "Research";
		infoPanelText [15].text = "Slots";
	}

	void UpdateChangeInfo(Resource res, int n){
		if (res.change > 0){
			infoPanelChanges[n].color = dGReen;
			infoPanelChanges[n].text = "+" + res.change.ToString("0");
		}
		if (res.change < 0){
			infoPanelChanges[n].color = red;
			infoPanelChanges[n].text = res.change.ToString("0");
		}
	}

	void resetChangeInfo (int j){
		//alvast volledig gedaan want superhandig lijstje om te hebben
		infoPanelChanges [j].text = "";
	}

	public void hideFloatingInfo(){
		floatingInfoPanel.SetActive (false);
	}

	void UpdateTimePanel (){
		nTicks++;
		nYears = nTicks / daysInAYear;
		timeTextHolder [3].text = nTicks.ToString ("0");
		timeTextHolder [2].text = nYears.ToString ("0");
	}
}
