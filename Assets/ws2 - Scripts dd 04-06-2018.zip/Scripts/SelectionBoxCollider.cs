﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelectionBoxCollider : MonoBehaviour {

	void OnTriggerEnter2D (Collider2D otherCol){
		print ("this = " + this + ", otherCol = " + otherCol + ", otherCol.gameObject = " + otherCol.gameObject);
	}
}
